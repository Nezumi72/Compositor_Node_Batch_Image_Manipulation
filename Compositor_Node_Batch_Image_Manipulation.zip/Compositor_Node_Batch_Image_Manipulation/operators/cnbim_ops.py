# pyright: reportInvalidTypeForm=false
import bpy
import pathlib
from mathutils import Vector


class FILE_OT_cnbim_ftypes(bpy.types.Operator):
    bl_idname = 'file.cnbim_ftypes'
    bl_label = "File Types"

    operation_type: bpy.props.EnumProperty(
        name="operation_type",
        items=(
            ("select_all", "Select all", "Select all file types"),
            ("deselect_all", "Deselect all", "Deselect all file types"),
        ),
        description="",
        default="select_all",
    )

    def execute(self, context):
        print(f'{self.bl_idname}:{self.operation_type}')
        props = context.window_manager.cnbim_props
        if self.operation_type == "select_all":
            set_state = True
        else:
            set_state = False
        for flag in props.supported:
            props[flag] = set_state
        return {'FINISHED'}


class NODE_OT_cnbim_base_nodes(bpy.types.Operator):
    """Modal Operator with Progress Bar"""
    bl_idname = "node.cnbim_basenodes"
    bl_label = "Modal Progress Example"

    def execute(self, context):
        wm = context.window_manager
        props = wm.cnbim_props
        cnbim_ng = bpy.data.node_groups.get("cnbim_ng")
        if not cnbim_ng:
            cnbim_ng = bpy.data.node_groups.new("cnbim_ng",'CompositorNodeTree')
            cnbim_img_nd = cnbim_ng.nodes.new('CompositorNodeImage')
            cnbim_file_nd = cnbim_ng.nodes.new('CompositorNodeOutputFile')
            cnbim_file_nd.format.media_type = 'IMAGE'
            cnbim_file_nd.file_output_items.new('RGBA', "")
            cnbim_view_nd = cnbim_ng.nodes.new('CompositorNodeViewer')
            cnbim_reroute_nd = cnbim_ng.nodes.new('NodeReroute')

            cnbim_ng.links.new(cnbim_view_nd.inputs[0], cnbim_reroute_nd.outputs[0])
            cnbim_ng.links.new(cnbim_file_nd.inputs[0], cnbim_reroute_nd.outputs[0])
            cnbim_ng.links.new(cnbim_reroute_nd.inputs[0], cnbim_img_nd.outputs[0])
            
            cnbim_img_nd.location = Vector((-550, 40))
            cnbim_reroute_nd.location = Vector((250, 0))
            cnbim_view_nd.location = Vector((350, 130))
            cnbim_file_nd.location = Vector((350, 60))
        context.scene.compositing_node_group = cnbim_ng
        return {'FINISHED'}


def get_region(context):
    wm = context.window_manager
    window = [window for window in wm.windows][0]
    screen = window.screen
    area = [area for area in screen.areas if area.type == "NODE_EDITOR"][0]
    region = [region for region in area.regions if region.type == 'UI'][0]
    return region

class FILE_OT_cnbim_progress(bpy.types.Operator):
    """Modal Operator with Progress Update"""
    bl_idname = "file.cnbim_progress"
    bl_label = "Modal Progress Example"

    @classmethod
    def poll(cls, context):
        props = context.window_manager.cnbim_props
        # force user selection of directories
        if props.src_dir == "" or props.dest_dir == "":
            return False
        # ensure valid directories
        if not pathlib.Path(props.src_dir).exists() and pathlib.Path(props.dest_dir).exists():
            return False
        if not pathlib.Path(props.src_dir).is_dir() and pathlib.Path(props.dest_dir).is_dir():
            return False
        # ensure nodetree
        if not props.comp_node_tree:
            return False
        # image node selected
        if not props.comp_node_tree.nodes.get(props.img_nd_name):
            return False
        # file node selected
        if not props.comp_node_tree.nodes.get(props.file_nd_name):
            return False
        return True

    def modal(self, context, event):
        props = context.window_manager.cnbim_props
        region = get_region(context)
        src_dir = pathlib.Path(props.src_dir)
        ftypes = ["." + f.split("_")[1] for f in props.keys() if f in props.supported and props[f]]
        files = []
        if props.sub_dir:
            files = [f for f in src_dir.rglob("*.*") if f.is_file() and f.suffix in ftypes]
        else:
            files = [f for f in src_dir.iterdir() if f.is_file() and f.suffix in ftypes]
        props.total = len(files)
        if event.type == 'TIMER':
            if props.progress < props.total:
                props.fname = str(files[props.progress].name)

                img_node = props.comp_node_tree.nodes.get(props.img_nd_name)
                file_node = props.comp_node_tree.nodes.get(props.file_nd_name)

                bpy.ops.image.open(filepath = str(files[props.progress]), directory = str(files[props.progress].parent))
                img_node.image = bpy.data.images.get(str(files[props.progress].name))

                if not props.dest_subfolders:
                    file_node.directory = props.dest_dir
                else:
                    relative_path = files[props.progress].relative_to(src_dir).parent
                    target_dir = pathlib.Path(props.dest_dir) / relative_path
                    file_node.directory = str(target_dir)
                
                file_node.file_name = str(files[props.progress].name)
                bpy.ops.render.render()
                img_node.image = bpy.data.images.get("Render Result")
                bpy.ops.outliner.orphans_purge()

                region.tag_redraw()
                props.progress += 1
            else:
                # Task finished
                context.window_manager.event_timer_remove(self._timer)
                props.progress = -1
                region.tag_redraw()
                # self.report({'INFO'}, "Task completed")
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        props = wm.cnbim_props
        props.progress = 0
        src_dir = pathlib.Path(props.src_dir)
        file_type = ".png"
        files = [f for f in src_dir.iterdir() if f.is_file() and f.name.endswith(file_type)]
        props.total = len(files)
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

_classes = [
    FILE_OT_cnbim_ftypes,
    NODE_OT_cnbim_base_nodes,
    FILE_OT_cnbim_progress,
]


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in _classes:
        bpy.utils.unregister_class(cls)
