# pyright: reportInvalidTypeForm=false
import bpy


def img_nd_list(self, context, edit_text):
    img_nd_names = [nd.name for nd in self.comp_node_tree.nodes if nd.name.startswith(edit_text) and nd.type == 'IMAGE']
    return img_nd_names

def file_nd_list(self, context, edit_text):
    file_nd_names = [nd.name for nd in self.comp_node_tree.nodes if nd.name.startswith(edit_text) and nd.type == 'OUTPUT_FILE']
    return file_nd_names

class FILE_PG_cnbim(bpy.types.PropertyGroup):
    src_dir: bpy.props.StringProperty(
        name="src_dir",
        description="Path of source directory",
        default="",
        subtype='DIR_PATH',
    )
    sub_dir: bpy.props.BoolProperty(
        name="sub_dir",
        description="Include sub directories",
        default=True,
    )
    supported = [
            "incl_jpg",
            "incl_exr",
            "incl_png",
            "incl_webp",
            "incl_bmp",
            "incl_cin",
            "incl_dpx",
            "incl_rgb",
            "incl_jp2",
            "incl_hdr",
            "incl_tga",
            "incl_tif",
            ]
    incl_jpg: bpy.props.BoolProperty(
        name="incl_jpg",
        description="Include .jpg images",
        default=True,
    )
    incl_exr: bpy.props.BoolProperty(
        name="incl_exr",
        description="Include .exr images",
        default=True,
    )
    incl_png: bpy.props.BoolProperty(
        name="incl_png",
        description="Include .png images",
        default=True,
    )
    incl_webp: bpy.props.BoolProperty(
        name="incl_webp",
        description="Include .webp images",
        default=True,
    )
    incl_bmp: bpy.props.BoolProperty(
        name="incl_bmp",
        description="Include .bmp images",
        default=True,
    )
    incl_cin: bpy.props.BoolProperty(
        name="incl_cin",
        description="Include .cin images",
        default=True,
    )
    incl_dpx: bpy.props.BoolProperty(
        name="incl_dpx",
        description="Include .dpx images",
        default=True,
    )
    incl_rgb: bpy.props.BoolProperty(
        name="incl_rgb",
        description="Include .rgb images",
        default=True,
    )
    incl_jp2: bpy.props.BoolProperty(
        name="incl_jp2",
        description="Include .jp2 images",
        default=True,
    )
    incl_hdr: bpy.props.BoolProperty(
        name="incl_hdr",
        description="Include .hdr images",
        default=True,
    )
    incl_tga: bpy.props.BoolProperty(
        name="incl_tga",
        description="Include .tga images",
        default=True,
    )
    incl_tif: bpy.props.BoolProperty(
        name="incl_tif",
        description="Include .tif images",
        default=True,
    )
    dest_dir: bpy.props.StringProperty(
        name="dest_dir",
        description="Path of output directory",
        default="",
        subtype='DIR_PATH',
    )
    dest_subfolders: bpy.props.BoolProperty(
        name="dest_subfolders",
        description="Recreate subfolder tree in destination folder",
        default=True,
    )
    fname: bpy.props.StringProperty(
        name="fname",
        description="Part of output file name",
        default="",
    )
    progress: bpy.props.IntProperty(
        name="progress",
        default=-1,
    )
    total: bpy.props.IntProperty(
        name="total",
        default=0,
    )
    comp_node_tree: bpy.props.PointerProperty(
        type=bpy.types.NodeTree
    )
    img_nd_name: bpy.props.StringProperty(
        search=img_nd_list,
    )
    file_nd_name: bpy.props.StringProperty(
        search=file_nd_list,
    )

_classes = [
    FILE_PG_cnbim,
]

def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.cnbim_props = bpy.props.PointerProperty(type=FILE_PG_cnbim)
    props = bpy.context.window_manager.cnbim_props
    for prop in props.bl_rna.properties:
        try:
            bpy.context.window_manager.cnbim_props[prop.name] = prop.default
        except KeyError:
            print(f"KeyError: {prop}")
        except AttributeError:
            print(f"AttributeError: {prop}")


def unregister():
    for cls in _classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.cnbim_props
