# pyright: reportInvalidTypeForm=false
import bpy


class FILE_PT_cnbim_main(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CNBIM"
    bl_idname = "FILE_PT_cnbim_main"
    bl_label = "CNBIM"

    @classmethod
    def poll(cls, context):
        screen = context.screen
        area = [area for area in screen.areas if area.type == "NODE_EDITOR"][0]
        return area.ui_type == 'CompositorNodeTree'

    def draw(self, context):
        props = context.window_manager.cnbim_props
        layout = self.layout
        col = layout.column()
        col.operator("file.cnbim_progress", text="Batch Process")
        if props.progress >= 0:
            col.label(text=f"Processing .. {props.progress} of {props.total}")
            col.label(text=f"{props.fname}")


class FILE_PT_cnbim_files_sub(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CNBIM"
    bl_idname = "FILE_PT_cnbim_files_sub"
    bl_label = "Files"
    bl_parent_id = "FILE_PT_cnbim_main"

    def draw(self, context):
        props = context.window_manager.cnbim_props
        layout = self.layout


class FILE_PT_cnbim_source_sub(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CNBIM"
    bl_idname = "FILE_PT_cnbim_source_sub"
    bl_label = "Input"
    bl_parent_id = "FILE_PT_cnbim_files_sub"

    def draw(self, context):
        props = context.window_manager.cnbim_props
        layout = self.layout
        col = layout.column()
        box = col.box()
        box.label(text="Directory")
        box.prop(props, "src_dir", text="")
        box.prop(props, "sub_dir", text = "Include Subdirectories")
        box = col.box()
        box.label(text="File Types")
        row = box.row()
        sel_op = row.operator("file.cnbim_ftypes", text = "Select All")
        sel_op.operation_type = 'select_all'
        desel_op = row.operator("file.cnbim_ftypes", text = "Deselect All")
        desel_op.operation_type = 'deselect_all'
        flow = box.grid_flow(row_major=True, columns=0, even_columns=True, even_rows=False, align=True)
        for prop in props.supported:
            col = flow.column()
            col.prop(props, prop, text = prop.split("_")[1])


class FILE_PT_cnbim_dest_sub(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CNBIM"
    bl_idname = "FILE_PT_cnbim_dest_sub"
    bl_label = "Output"
    bl_parent_id = "FILE_PT_cnbim_files_sub"

    def draw(self, context):
        props = context.window_manager.cnbim_props
        layout = self.layout
        col = layout.column()
        box = col.box()
        box.label(text="Directory")
        box.prop(props, "dest_dir", text="")
        box.prop(props, "dest_subfolders", text="Use/Create Subfolder Structure")


class FILE_PT_cnbim_nodes_sub(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "CNBIM"
    bl_idname = "FILE_PT_cnbim_nodes_sub"
    bl_label = "Nodes"
    bl_parent_id = "FILE_PT_cnbim_main"

    def draw(self, context):
        props = context.window_manager.cnbim_props
        layout = self.layout
        col = layout.column()
        col.operator("node.cnbim_basenodes", text="Add Base Nodes")
        col.prop(props, "comp_node_tree")
        col.prop(props, "img_nd_name")
        col.prop(props, "file_nd_name")


_classes = [
    FILE_PT_cnbim_main,
    FILE_PT_cnbim_files_sub,
    FILE_PT_cnbim_source_sub,
    FILE_PT_cnbim_dest_sub,
    FILE_PT_cnbim_nodes_sub,
]

def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in _classes:
        bpy.utils.unregister_class(cls)
